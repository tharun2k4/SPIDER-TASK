import 'package:flutter/material.dart';
class Length extends StatefulWidget {
  const Length({Key? key}) : super(key: key);

  @override
  State<Length> createState() => _LengthState();
}

class _LengthState extends State<Length> {
  late double input;
  late double output;
  late bool fOrC;

  @override
  void initState() {
    super.initState();
    input = 0.0;
    output = 0.0;
    fOrC = true;
  }
  @override
  Widget build(BuildContext context) {
    TextField inputField = TextField(
      keyboardType: TextInputType.number,
      onChanged: (str) {
        try {
          input = double.parse(str);
        } catch (e) {
          input = 0.0;
        }
      },
      decoration: InputDecoration(
        labelText:
        "Input a Value in ${fOrC == false ? "Kilo-Meter" : "Meter"}",
      ),
      textAlign: TextAlign.center,
    );
    Container tempSwitch = Container(
      padding: EdgeInsets.all(15.0),
      child: Row(
        children: <Widget>[
          Text("Kms"),
          Radio<bool>(
              groupValue: fOrC,
              value: false,
              onChanged: (v) {
                setState(() {
                  fOrC = v!;
                });
              }),
          Text("meter"),
          Radio<bool>(
              groupValue: fOrC,
              value: true,
              onChanged: (v) {
                setState(() {
                  fOrC = v!;
                });
              }),
        ],
      ),
    );


    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            inputField,
            tempSwitch,
            Container(
              child: ElevatedButton(
                child: Text("Calculate"),
                onPressed: () {
                  setState(() {
                    fOrC == false
                        ? output = input*1000
                        : output = input* 0.001;
                  }
                  );
                  /* AlertDialog dialog = AlertDialog(
            content: fOrC == false
                ? Text(
                "${input.toStringAsFixed(2)} F : ${output.toStringAsFixed(2)} C")
                : Text(
                "${input.toStringAsFixed(2)} C : ${output.toStringAsFixed(2)} F"),
              showDialog(context: context, child: dialog);
          );*/
                },
              ),
            ),
            SizedBox(height: 20,),
            (fOrC == false)?
            Text(
                "${input.toStringAsFixed(2)} Kms : ${output.toStringAsFixed(2)} meter")
                : Text(
                "${input.toStringAsFixed(2)} meter : ${output.toStringAsFixed(2)} Kms"),
          ],
        ),
      ),
    );
  }
}
