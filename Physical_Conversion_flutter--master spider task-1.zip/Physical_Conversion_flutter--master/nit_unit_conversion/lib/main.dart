import 'package:flutter/material.dart';
import 'package:nit_unit_conversion/Weight.dart';
import 'package:nit_unit_conversion/length.dart';
import 'package:nit_unit_conversion/speed.dart';
import 'package:nit_unit_conversion/temperature.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: TabsScreen(),
    );
  }
}

class TabsScreen extends StatefulWidget {
  @override
  State<TabsScreen> createState() => _TabsScreenState();
}

class _TabsScreenState extends State<TabsScreen> {
  int tabView = 1;

  @override
  Widget build(BuildContext context) {
    print('Just entered : $tabView');
    return DefaultTabController(
      length:4,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(60.0),
          child: AppBar(
            automaticallyImplyLeading: false,
            centerTitle: false,
            backgroundColor: Colors.deepPurple,
            bottom: TabBar(
              indicatorColor: Colors.white,
              tabs: [
                Icon(Icons.speed_outlined),
                Icon(Icons.heat_pump_outlined),
                Icon(Icons.monitor_weight_outlined),
                Icon(Icons.stacked_line_chart_sharp)
              ],
            ),
          ),
        ),
        body: TabBarView(
          children: [
            Speed(),
            Temperature(),
            Weight(),
            Length()
          ],
        ),
      ),
    );
  }
}